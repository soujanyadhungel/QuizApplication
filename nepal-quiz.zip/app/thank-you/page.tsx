import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function ThankYou() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-green-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">धन्यवाद!</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center mb-4">
            प्रश्नोत्तरी पूरा गर्नुभएकोमा बधाई छ! तपाईंलाई बजाज पल्सर २२० मोटरसाइकल जित्ने ड्रमा प्रवेश गराइएको छ।
          </p>
          <p className="text-center mb-4">
            जित्ने सम्भावना बढाउन चाहनुहुन्छ? फेरि प्रश्नोत्तरी दिनुहोस्!
          </p>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Link href="/">
            <Button size="lg">फेरि प्रयास गर्नुहोस्</Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

