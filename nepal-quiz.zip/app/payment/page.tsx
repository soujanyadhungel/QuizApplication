import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Payment() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-green-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">भुक्तानी आवश्यक</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center mb-4">
            प्रश्नोत्तरी सुरु गर्न र बजाज पल्सर २२० जित्ने ड्रमा प्रवेश गर्न, कृपया १०० नेपाली रुपैयाँ ट्रान्सफर गर्नुहोस्।
          </p>
          <div className="bg-gray-100 p-4 rounded-lg mb-4">
            <p className="text-center font-semibold">eSewa विवरण:</p>
            <p className="text-center">eSewa ID: 9876543210</p>
            <p className="text-center">रकम: NPR 100</p>
            <div className="flex justify-center mt-4">
              <img 
                src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=eSewa:9876543210:100" 
                alt="eSewa QR कोड" 
                className="w-64 h-64"
              />
            </div>
          </div>
          <p className="text-sm text-gray-600 text-center">
            भुक्तानी गरिसकेपछि, प्रश्नोत्तरी सुरु गर्न तलको बटन क्लिक गर्नुहोस्।
          </p>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Link href="/quiz">
            <Button size="lg" className="bg-[#003893] hover:bg-[#002d7a]">
              मैले eSewa मार्फत भुक्तानी गरेको छु
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

