'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function Home() {
  const [phone, setPhone] = useState('')
  const [error, setError] = useState('')
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate Nepalese phone number (must start with 9 and be 10 digits)
    const phoneRegex = /^9[0-9]{9}$/
    if (!phoneRegex.test(phone)) {
      setError('कृपया मान्य नेपाली मोबाइल नम्बर प्रविष्ट गर्नुहोस्')
      return
    }

    router.push('/payment')
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-green-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">बजाज पल्सर २२० जित्नुहोस्!</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center mb-4">
            नवीनतम बजाज पल्सर २२० मोटरसाइकल जित्ने मौका पाउन नेपालको इतिहास, राजनीतिज्ञ र अर्थव्यवस्था सम्बन्धी हाम्रो रोमाञ्चक प्रश्नोत्तरीमा सहभागी हुनुहोस्!
          </p>
          <img 
            src="https://www.bikes4sale.in/pictures/default/bajaj-pulsar-220f/bajaj-pulsar-220f-640.jpg" 
            alt="बजाज पल्सर २२० मोटरसाइकल" 
            className="w-full h-auto rounded-lg mb-4 object-contain"
          />
          <p className="text-sm text-gray-600 text-center mb-6">
            ड्रमा प्रवेश गर्न सबै २० प्रश्नहरूको सही उत्तर दिनुहोस्। आफ्नो ज्ञान परीक्षण गर्नुहोस् र जित्ने सम्भावना बढाउनुहोस्!
          </p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone">मोबाइल नम्बर</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="98xxxxxxxx"
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value)
                  setError('')
                }}
                className="text-lg"
              />
              {error && (
                <p className="text-sm text-red-500 mt-1">{error}</p>
              )}
            </div>
            <Button type="submit" className="w-full bg-[#003893] hover:bg-[#002d7a]" size="lg">
              सुरु गर्नुहोस्
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

