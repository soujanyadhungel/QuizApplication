'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

const questions = [
  {
    question: "नेपालको पहिलो राष्ट्रपति को थिए?",
    options: ["राम बरण यादव", "विद्यादेवी भण्डारी", "पुष्पकमल दाहाल", "शेरबहादुर देउवा"],
    correctAnswer: 0
  },
  {
    question: "नेपालको संविधान कुन सालमा जारी भयो?",
    options: ["२०६२", "२०६३", "२०७२", "२०७४"],
    correctAnswer: 2
  },
  {
    question: "नेपालको राष्ट्रिय फूल के हो?",
    options: ["गुराँस", "लालीगुराँस", "मखमली", "सुनाखरी"],
    correctAnswer: 1
  },
  {
    question: "नेपालको सबैभन्दा अग्लो हिमाल कुन हो?",
    options: ["कञ्चनजङ्घा", "मकालु", "धौलागिरी", "सगरमाथा"],
    correctAnswer: 3
  },
  {
    question: "नेपालको राष्ट्रिय खेल के हो?",
    options: ["क्रिकेट", "फुटबल", "भलिबल", "डण्डीबियो"],
    correctAnswer: 2
  },
  {
    question: "नेपालको पहिलो प्रधानमन्त्री को थिए?",
    options: ["भीमसेन थापा", "जंगबहादुर राणा", "मत्स्येन्द्रनाथ", "पद्म शमशेर"],
    correctAnswer: 1
  },
  {
    question: "नेपालको केन्द्रीय बैंक कुन हो?",
    options: ["नेपाल बैंक", "राष्ट्रिय वाणिज्य बैंक", "नेपाल राष्ट्र बैंक", "कृषि विकास बैंक"],
    correctAnswer: 2
  },
  {
    question: "नेपालको सबैभन्दा ठूलो ताल कुन हो?",
    options: ["फेवा ताल", "रारा ताल", "बेगनास ताल", "टिस्टो ताल"],
    correctAnswer: 1
  },
  {
    question: "नेपालको राष्ट्रिय जनावर कुन हो?",
    options: ["गाई", "गैंडा", "हात्ती", "कस्तुरी मृग"],
    correctAnswer: 1
  },
  {
    question: "नेपालको पहिलो विश्वविद्यालय कुन हो?",
    options: ["त्रिभुवन विश्वविद्यालय", "काठमाडौं विश्वविद्यालय", "पूर्वाञ्चल विश्वविद्यालय", "पोखरा विश्वविद्यालय"],
    correctAnswer: 0
  },
  {
    question: "नेपालको राष्ट्रिय पक्षी कुन हो?",
    options: ["कालिज", "डाँफे", "मुनाल", "सारस"],
    correctAnswer: 1
  },
  {
    question: "नेपालको पहिलो हवाई अड्डा कहाँ बनेको थियो?",
    options: ["काठमाडौं", "सिमरा", "भैरहवा", "गौचर"],
    correctAnswer: 3
  },
  {
    question: "नेपालको पहिलो राजमार्ग कुन हो?",
    options: ["त्रिभुवन राजपथ", "महेन्द्र राजमार्ग", "अरनिको राजमार्ग", "प्रृथ्वी राजमार्ग"],
    correctAnswer: 0
  },
  {
    question: "नेपालको पहिलो राष्ट्रिय निकुञ्ज कुन हो?",
    options: ["चितवन राष्ट्रिय निकुञ्ज", "सगरमाथा राष्ट्रिय निकुञ्ज", "लाङटाङ राष्ट्रिय निकुञ्ज", "रारा राष्ट्रिय निकुञ्ज"],
    correctAnswer: 0
  },
  {
    question: "नेपालको मुद्रा के हो?",
    options: ["रुपैयाँ", "टका", "मोहर", "पैसा"],
    correctAnswer: 0
  },
  {
    question: "नेपालको राष्ट्रिय खेलाडी को हो?",
    options: ["पारस खड्का", "सन्दीप लामिछाने", "गौरिका सिंह", "बिनोद दास"],
    correctAnswer: 1
  },
  {
    question: "नेपालको पहिलो संवैधानिक राजा को थिए?",
    options: ["महेन्द्र", "बीरेन्द्र", "त्रिभुवन", "ज्ञानेन्द्र"],
    correctAnswer: 2
  },
  {
    question: "नेपालको सबैभन्दा लामो नदी कुन हो?",
    options: ["कर्णाली", "कोशी", "गण्डकी", "महाकाली"],
    correctAnswer: 0
  },
  {
    question: "नेपालको पहिलो नोबेल पुरस्कार विजेता को हुन्?",
    options: ["भीम भक्त थापा", "लक्ष्मी प्रसाद देवकोटा", "महाकवि देवकोटा", "कोही छैन"],
    correctAnswer: 3
  },
  {
    question: "नेपालको राष्ट्रिय गीत कसले लेखेको हो?",
    options: ["प्रदीप कुमार राई", "भानुभक्त आचार्य", "लक्ष्मी प्रसाद देवकोटा", "माधव प्रसाद घिमिरे"],
    correctAnswer: 0
  }
]

export default function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const router = useRouter()

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
    } else {
      router.push('/thank-you')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-green-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">नेपाल प्रश्नोत्तरी</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-lg font-semibold mb-4">
            प्रश्न {currentQuestion + 1} / {questions.length}
          </p>
          <p className="mb-4">{questions[currentQuestion].question}</p>
          <RadioGroup onValueChange={(value) => setSelectedAnswer(parseInt(value))}>
            {questions[currentQuestion].options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2 mb-2">
                <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                <Label htmlFor={`option-${index}`}>{option}</Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button 
            onClick={handleNext} 
            disabled={selectedAnswer === null}
            className="bg-[#003893] hover:bg-[#002d7a]"
          >
            {currentQuestion < questions.length - 1 ? 'अर्को प्रश्न' : 'समाप्त'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

